var struct_base_modules_1_1_configuration =
[
    [ "presentedListElementCount", "struct_base_modules_1_1_configuration.html#a6f44c8a1364b0add82554f85f9974e80", null ],
    [ "setPresentedListElementCount", "struct_base_modules_1_1_configuration.html#accb095e8596bcb6e6e22a73b1104d769", null ]
];