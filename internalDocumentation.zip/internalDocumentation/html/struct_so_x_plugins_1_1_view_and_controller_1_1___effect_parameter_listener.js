var struct_so_x_plugins_1_1_view_and_controller_1_1___effect_parameter_listener =
[
    [ "audioProcessor", "struct_so_x_plugins_1_1_view_and_controller_1_1___effect_parameter_listener.html#a0b7b4c21dc14b8b9687b4463f12b1a11", null ]
];