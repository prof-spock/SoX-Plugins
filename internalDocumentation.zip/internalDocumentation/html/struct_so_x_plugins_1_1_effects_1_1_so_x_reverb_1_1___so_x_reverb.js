var struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1___so_x_reverb =
[
    [ "_SoXReverb", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1___so_x_reverb.html#a8018305692dc9b2b10fa27683dd27b72", null ],
    [ "_SoXReverb", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1___so_x_reverb.html#ac647390009685e279db4f21e0234be96", null ],
    [ "~_SoXReverb", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1___so_x_reverb.html#aca9447d392897a75eaaa2a9b05af3472", null ],
    [ "apply", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1___so_x_reverb.html#a0227583b7534cf58f5170374e1c862bd", null ],
    [ "operator=", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1___so_x_reverb.html#ab163cc44186fb6e0d5c5afbf2054b7f5", null ],
    [ "resize", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1___so_x_reverb.html#af4ed8610c54f7b7122b2f26b89f71fac", null ],
    [ "setParameters", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1___so_x_reverb.html#ae1460be7c18c73f1ccc1fc9795a1b1ad", null ],
    [ "tailLength", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1___so_x_reverb.html#ab84f8c317485b795609b27dd7b96be95", null ],
    [ "toString", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1___so_x_reverb.html#a5d99f1630f60b94889492b29c46c8e2e", null ],
    [ "_effectParameterData", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1___so_x_reverb.html#a97bf1df3dd5607c35f518ccad1d2d9f1", null ]
];