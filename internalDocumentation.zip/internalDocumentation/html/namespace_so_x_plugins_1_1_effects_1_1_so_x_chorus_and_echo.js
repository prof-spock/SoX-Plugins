var namespace_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo =
[
    [ "_DelayStageParameterData", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1___delay_stage_parameter_data.html", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1___delay_stage_parameter_data" ],
    [ "_EffectDescriptor_CECH", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1___effect_descriptor___c_e_c_h.html", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1___effect_descriptor___c_e_c_h" ],
    [ "SoXChorusAndEcho_AudioEffect", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1_so_x_chorus_and_echo___audio_effect.html", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1_so_x_chorus_and_echo___audio_effect" ],
    [ "SoXChorusAndEcho_AudioProcessor", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1_so_x_chorus_and_echo___audio_processor.html", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1_so_x_chorus_and_echo___audio_processor" ],
    [ "_StageList", "namespace_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo.html#a1a8cc007a2e96bad6c038fe861ae0a79", null ],
    [ "_EffectKind", "namespace_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo.html#a544547d9d94449e796f9a48aa4fd96c4", [
      [ "unknown", "namespace_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo.html#a544547d9d94449e796f9a48aa4fd96c4aad921d60486366258809553a3db49a4a", null ],
      [ "chorus", "namespace_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo.html#a544547d9d94449e796f9a48aa4fd96c4a970ae9dcbe08d5b400eee5d177dea886", null ],
      [ "tappedDelay", "namespace_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo.html#a544547d9d94449e796f9a48aa4fd96c4ae1370cb451b1e46ff996cec55aa8f2f1", null ],
      [ "delaySequence", "namespace_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo.html#a544547d9d94449e796f9a48aa4fd96c4aa8ce5288a272f235b8a0ac3de1524881", null ]
    ] ]
];