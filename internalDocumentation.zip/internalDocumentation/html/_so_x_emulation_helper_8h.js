var _so_x_emulation_helper_8h =
[
    [ "SoXPlugins::Helpers::SoXEmulationHelper", "struct_so_x_plugins_1_1_helpers_1_1_so_x_emulation_helper.html", "struct_so_x_plugins_1_1_helpers_1_1_so_x_emulation_helper" ]
];