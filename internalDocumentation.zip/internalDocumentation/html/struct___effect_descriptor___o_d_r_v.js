var struct___effect_descriptor___o_d_r_v =
[
    [ "_EffectDescriptor_ODRV", "struct___effect_descriptor___o_d_r_v.html#aea7bba8383ef0bede1e42a050b850bef", null ],
    [ "apply", "struct___effect_descriptor___o_d_r_v.html#a29e440053490c0c96b4ccf8963f65e05", null ],
    [ "toString", "struct___effect_descriptor___o_d_r_v.html#a0bc0bd5f8ee2b971df2e0f1c18c2b963", null ],
    [ "updateSettings", "struct___effect_descriptor___o_d_r_v.html#af4fdc8c043ed04c26d0a3ab195c455a0", null ],
    [ "channelCount", "struct___effect_descriptor___o_d_r_v.html#af60db3045f48df72de8076be3ea61b9d", null ],
    [ "colour", "struct___effect_descriptor___o_d_r_v.html#af9ecea5af77467cb6e836b50040b7fa0", null ],
    [ "effect", "struct___effect_descriptor___o_d_r_v.html#a81deb6790934fd36dd4280a2de1c66ec", null ],
    [ "gain", "struct___effect_descriptor___o_d_r_v.html#a04beb6537727cb27fa03ff2d9042955e", null ],
    [ "previousInputDataPointList", "struct___effect_descriptor___o_d_r_v.html#a4991c84950a09135ca69453c134c18c2", null ],
    [ "previousOutputDataPointList", "struct___effect_descriptor___o_d_r_v.html#a45ee0ace0ea3a41947f4c581e4cecf75", null ]
];