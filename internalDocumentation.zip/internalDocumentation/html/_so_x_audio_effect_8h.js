var _so_x_audio_effect_8h =
[
    [ "SoXPlugins::Effects::SoXAudioEffect", "struct_so_x_plugins_1_1_effects_1_1_so_x_audio_effect.html", "struct_so_x_plugins_1_1_effects_1_1_so_x_audio_effect" ],
    [ "SoXEffectParameterMap", "struct_so_x_effect_parameter_map.html", "struct_so_x_effect_parameter_map" ],
    [ "SoXValueChangeObserver", "struct_so_x_value_change_observer.html", "struct_so_x_value_change_observer" ],
    [ "SoXValueChangeNotification", "_so_x_audio_effect_8h.html#a445ec43c8d0d8a5489ebb50a05415df7", null ],
    [ "SoXValueChangeKind", "_so_x_audio_effect_8h.html#a375d28eeb638976b8eba48c078910178", null ]
];