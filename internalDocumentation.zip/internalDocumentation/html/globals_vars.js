var globals_vars =
[
    [ "_", "globals_vars.html", null ],
    [ "a", "globals_vars_a.html", null ],
    [ "c", "globals_vars_c.html", null ],
    [ "d", "globals_vars_d.html", null ],
    [ "e", "globals_vars_e.html", null ],
    [ "m", "globals_vars_m.html", null ],
    [ "p", "globals_vars_p.html", null ],
    [ "s", "globals_vars_s.html", null ],
    [ "u", "globals_vars_u.html", null ]
];