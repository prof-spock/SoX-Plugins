var _wave_form_8h =
[
    [ "Audio::WaveForm", "struct_audio_1_1_wave_form.html", "struct_audio_1_1_wave_form" ],
    [ "Natural", "struct_natural.html", "struct_natural" ],
    [ "Radians", "struct_radians.html", "struct_radians" ],
    [ "Object", "_wave_form_8h.html#a46e9a7b488f5aadebd3b8413adf482f6", null ],
    [ "Audio::WaveFormIteratorState", "namespace_audio.html#a1dc88b29af75327455e29e0d3d2563a8", null ],
    [ "Audio::ValuePrecision", "namespace_audio.html#aced9b3ac86f4cb7204e9cc72e1d989c8", [
      [ "Audio::ValuePrecision::integerPrecision", "namespace_audio.html#aced9b3ac86f4cb7204e9cc72e1d989c8add45beab0d82232d6991076dc8b65ac1", null ],
      [ "Audio::ValuePrecision::singlePrecision", "namespace_audio.html#aced9b3ac86f4cb7204e9cc72e1d989c8a6158b982cea925737abd1972117e85a9", null ],
      [ "Audio::ValuePrecision::doublePrecision", "namespace_audio.html#aced9b3ac86f4cb7204e9cc72e1d989c8a0d8ef81b94b3e8e2f4bb8d51e71831c3", null ]
    ] ],
    [ "Audio::WaveFormKind", "namespace_audio.html#a8cf082e76c27a75bb55cc50f17d0475c", [
      [ "Audio::WaveFormKind::sine", "namespace_audio.html#a8cf082e76c27a75bb55cc50f17d0475ca925212d1624625aed9491413b4b7be05", null ],
      [ "Audio::WaveFormKind::triangle", "namespace_audio.html#a8cf082e76c27a75bb55cc50f17d0475cacef44b46f16ae8ecf664df4266ffdbf9", null ]
    ] ],
    [ "Audio::stringToWaveFormKind", "namespace_audio.html#afb924ba2c19839c2128ab2b4a79c4ce7", null ],
    [ "Audio::valuePrecisionToString", "namespace_audio.html#ace29e5aab5424a301a0e5f357491959a", null ],
    [ "Audio::waveFormKindToString", "namespace_audio.html#a756c708f5d7d400202219a7a1adaeb13", null ]
];