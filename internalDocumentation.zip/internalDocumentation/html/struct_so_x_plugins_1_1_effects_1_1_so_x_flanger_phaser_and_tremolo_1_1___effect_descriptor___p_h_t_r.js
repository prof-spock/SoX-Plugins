var struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___p_h_t_r =
[
    [ "toString", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___p_h_t_r.html#af16fe4ff7a3ee64182609429687f3a29", null ],
    [ "delay", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___p_h_t_r.html#a601de5fc89a54b94cca006122966e8e0", null ],
    [ "delayLineLength", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___p_h_t_r.html#af265ceb4d7691bfa37c5cb02e345c81b", null ],
    [ "delayLineList", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___p_h_t_r.html#adc703f1025bbac5654c4e84b3548c550", null ],
    [ "depth", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___p_h_t_r.html#a90faf16513cf8320e75c684cbd91dae5", null ],
    [ "frequency", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___p_h_t_r.html#ae9939851bfb7f23f7f88506b6331cbee", null ],
    [ "inGain", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___p_h_t_r.html#a16303789f50513bb9c7d81d1e6eef011", null ],
    [ "interpolationOrder", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___p_h_t_r.html#a31b2f66bd47fbc518acc961b3c41bbab", null ],
    [ "isPhaser", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___p_h_t_r.html#a6eb436ccbe5da936b1b167b1e739be87", null ],
    [ "outGain", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___p_h_t_r.html#aa7450d7465ca977e023f1c23014ba8a5", null ],
    [ "regeneration", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___p_h_t_r.html#a90b33bec5ae1001f4276d02109d3d3d2", null ],
    [ "timeOffset", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___p_h_t_r.html#a3981dbd6eb66c68ce6b446657d4714b6", null ],
    [ "waveForm", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___p_h_t_r.html#a47fe28ff592cc21263c215fd0b0d6c15", null ],
    [ "waveFormKind", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___p_h_t_r.html#a0c267fc2551ed0b74ae003debfa3008a", null ]
];