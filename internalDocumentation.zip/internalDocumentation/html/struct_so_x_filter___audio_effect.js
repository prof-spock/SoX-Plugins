var struct_so_x_filter___audio_effect =
[
    [ "_applyForFrame", "struct_so_x_filter___audio_effect.html#a79ed5b2ee0121073c64e348aa445138a", null ],
    [ "_effectDescriptorToString", "struct_so_x_filter___audio_effect.html#a7a7a56f6a5f0fb2e55d9bf6d845b7864", null ],
    [ "_handleDataPointRateChange", "struct_so_x_filter___audio_effect.html#a2ccf3a31022214a2ba916e021251ad31", null ],
    [ "_setValueInternal", "struct_so_x_filter___audio_effect.html#abd60f51d796b7d572a46ac880f23a571", null ],
    [ "name", "struct_so_x_filter___audio_effect.html#affd8c6966f593b4f3ecfa619bc07ffcd", null ],
    [ "recalculate", "struct_so_x_filter___audio_effect.html#ac09f28f4403cef344cc18264ae24df60", null ],
    [ "setDefaultValues", "struct_so_x_filter___audio_effect.html#a44330149d329f228f5ebe54dd3943806", null ]
];