var searchData=
[
  ['soxeffectparameterkind_0',['SoXEffectParameterKind',['../namespace_so_x_plugins_1_1_helpers.html#a782a7054af4fe4d3821edfd71bb275d3',1,'SoXPlugins::Helpers::SoXEffectParameterKind'],['../_so_x_effect_parameter_map_8cpp.html#a782a7054af4fe4d3821edfd71bb275d3',1,'SoXEffectParameterKind:&#160;SoXEffectParameterMap.h'],['../_so_x_audio_editor_widget_8cpp.html#a782a7054af4fe4d3821edfd71bb275d3',1,'SoXEffectParameterKind:&#160;SoXEffectParameterMap.h'],['../_so_x_audio_processor_8cpp.html#a782a7054af4fe4d3821edfd71bb275d3',1,'SoXEffectParameterKind:&#160;SoXEffectParameterMap.h']]],
  ['soxvaluechangekind_1',['SoXValueChangeKind',['../namespace_so_x_plugins_1_1_helpers.html#a375d28eeb638976b8eba48c078910178',1,'SoXPlugins::Helpers::SoXValueChangeKind'],['../_so_x_audio_effect_8h.html#a375d28eeb638976b8eba48c078910178',1,'SoXValueChangeKind:&#160;SoXValueChangeObserver.h']]]
];
