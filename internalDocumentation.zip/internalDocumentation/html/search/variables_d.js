var searchData=
[
  ['newlinestring_0',['newlineString',['../struct_base_modules_1_1_string_util.html#a24d32ab0738d93d563d72b301a69f3f5',1,'BaseModules::StringUtil::newlineString'],['../struct_string_util.html#a24d32ab0738d93d563d72b301a69f3f5',1,'StringUtil::newlineString']]]
];
