var searchData=
[
  ['valueprecision_0',['ValuePrecision',['../namespace_audio.html#aced9b3ac86f4cb7204e9cc72e1d989c8',1,'Audio::ValuePrecision'],['../_wave_form_8cpp-inc.html#aced9b3ac86f4cb7204e9cc72e1d989c8',1,'ValuePrecision:&#160;WaveForm.h'],['../_so_x_chorus_and_echo___audio_effect_8cpp.html#aced9b3ac86f4cb7204e9cc72e1d989c8',1,'ValuePrecision:&#160;WaveForm.h'],['../_so_x_flanger_phaser_and_tremolo___audio_effect_8cpp.html#aced9b3ac86f4cb7204e9cc72e1d989c8',1,'ValuePrecision:&#160;WaveForm.h']]]
];
