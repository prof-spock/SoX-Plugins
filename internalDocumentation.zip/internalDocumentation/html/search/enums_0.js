var searchData=
[
  ['_5feffectkind_0',['_EffectKind',['../namespace_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo.html#a544547d9d94449e796f9a48aa4fd96c4',1,'SoXPlugins::Effects::SoXChorusAndEcho::_EffectKind'],['../namespace_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo.html#ac3c13c66b983842b1ec8a6fb5072ff4f',1,'SoXPlugins::Effects::SoXFlangerPhaserAndTremolo::_EffectKind'],['../_so_x_chorus_and_echo___audio_effect_8cpp.html#a544547d9d94449e796f9a48aa4fd96c4',1,'_EffectKind:&#160;SoXChorusAndEcho_AudioEffect.cpp'],['../_so_x_flanger_phaser_and_tremolo___audio_effect_8cpp.html#ac3c13c66b983842b1ec8a6fb5072ff4f',1,'_EffectKind:&#160;SoXFlangerPhaserAndTremolo_AudioEffect.cpp']]],
  ['_5floggingstate_1',['_LoggingState',['../namespace_base_modules.html#ae1d9048d43db9507aa672f29446e5c14',1,'BaseModules::_LoggingState'],['../_logging_support_8cpp.html#ae1d9048d43db9507aa672f29446e5c14',1,'_LoggingState:&#160;LoggingSupport.cpp']]]
];
