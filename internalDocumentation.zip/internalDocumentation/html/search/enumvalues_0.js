var searchData=
[
  ['globalchange_0',['globalChange',['../namespace_so_x_plugins_1_1_helpers.html#a375d28eeb638976b8eba48c078910178ab6c1503bf3ca26a7932d2f6227ec2ba3',1,'SoXPlugins::Helpers']]]
];
