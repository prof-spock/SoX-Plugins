var searchData=
[
  ['nochange_0',['noChange',['../namespace_so_x_plugins_1_1_helpers.html#a375d28eeb638976b8eba48c078910178ad37ddf64a872257d1805878d69aa9e6d',1,'SoXPlugins::Helpers']]]
];
