var struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t =
[
    [ "applyForFrame", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#a13f7d19f07735fef2cd5a9993b62dbb6", null ],
    [ "internalState", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#aea9852422ad51375bf0538b3dbb7f264", null ],
    [ "toString", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#a5f483949ddcd20e6a6406c17e9aa6191", null ],
    [ "updateSettings", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#aac54cee93bec76e9b33c0deff936dbf5", null ],
    [ "delay", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#a64ba37ca62680f08b5495c19095d6c9f", null ],
    [ "delayLineLengthInDataPoints", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#af797c8924ffa6eb9b6ed9559f7dc3bd4", null ],
    [ "delayLineList", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#ada817c96f9328f0dd1676d9e7236351f", null ],
    [ "depth", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#abe4e4aee65e303e08f12eed3f1658012", null ],
    [ "depthInPct", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#ad8eb5fcb611b65e807365540da6a4558", null ],
    [ "frequency", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#a37325686dbba75f04dbfd3b78ac8d345", null ],
    [ "inGain", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#a4cf5ce2ac2bbedae7e17d2184e784f2e", null ],
    [ "interpolationOrder", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#ae3c2db5aae76fd8e9c2c4307df6afd09", null ],
    [ "kind", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#a1163f511f197f9ebf24d1900ed95579e", null ],
    [ "outGain", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#acf735d29b72cea3b275b4aeea54a5f59", null ],
    [ "phase", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#a118b9985b96e9ead92a7b4badb4c4eb4", null ],
    [ "previousDataPointList", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#a8c6fc8096dc32d179e3692b12cef7e5b", null ],
    [ "regeneration", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#a3929c09a1c1946ce109c2d7257b837a4", null ],
    [ "timeOffset", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#a4b0bfd5e591f3851741eb69c6a26ecfe", null ],
    [ "waveForm", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#a94aee1f806ff3f14ca92e408c36c0ff1", null ],
    [ "waveFormKind", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#a160974f6a660e2084950fd6e788060bf", null ],
    [ "width", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html#af54a41a3e06db542e61635a9b46a5610", null ]
];