var _so_x_parameter_value_change_kind_8h =
[
    [ "SoXPlugins::Helpers::SoXParameterValueChangeKind", "namespace_so_x_plugins_1_1_helpers.html#aeb3d6a9a55d48b23c0f515258422f716", [
      [ "SoXPlugins::Helpers::SoXParameterValueChangeKind::globalChange", "namespace_so_x_plugins_1_1_helpers.html#aeb3d6a9a55d48b23c0f515258422f716ab6c1503bf3ca26a7932d2f6227ec2ba3", null ],
      [ "SoXPlugins::Helpers::SoXParameterValueChangeKind::pageChange", "namespace_so_x_plugins_1_1_helpers.html#aeb3d6a9a55d48b23c0f515258422f716a2c581a6ab7d343813e8926b1db2dabba", null ],
      [ "SoXPlugins::Helpers::SoXParameterValueChangeKind::pageCountChange", "namespace_so_x_plugins_1_1_helpers.html#aeb3d6a9a55d48b23c0f515258422f716a6865c555494c8184927c5f3a80e6cde7", null ],
      [ "SoXPlugins::Helpers::SoXParameterValueChangeKind::parameterChange", "namespace_so_x_plugins_1_1_helpers.html#aeb3d6a9a55d48b23c0f515258422f716ad099a3a097d6349d897c64f783e1239d", null ],
      [ "SoXPlugins::Helpers::SoXParameterValueChangeKind::noChange", "namespace_so_x_plugins_1_1_helpers.html#aeb3d6a9a55d48b23c0f515258422f716ad37ddf64a872257d1805878d69aa9e6d", null ]
    ] ],
    [ "SoXParameterValueChangeKind_toString", "_so_x_parameter_value_change_kind_8h.html#a91b3d528629ed2320dff240465ab3f32", null ]
];