var struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1___delay_stage_parameter_data =
[
    [ "toString", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1___delay_stage_parameter_data.html#a175daa7f38058584474b39e70a494bb7", null ],
    [ "decay", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1___delay_stage_parameter_data.html#a84449e1d427375fb2f491a6dd63ba01f", null ],
    [ "delay", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1___delay_stage_parameter_data.html#a7b13643e61106ee5575d2ffaea45c44f", null ],
    [ "depth", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1___delay_stage_parameter_data.html#a3407cdd0d08f21f32b12293d43f3ba8e", null ],
    [ "frequency", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1___delay_stage_parameter_data.html#af1f01f8f6921c81627c555f7f31fc43d", null ],
    [ "isChorusStage", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1___delay_stage_parameter_data.html#a34af138e7365928aa746b50b32b66c21", null ],
    [ "modulationKind", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1___delay_stage_parameter_data.html#ab4ec9d2f8eb9358b74f004ee1da58987", null ],
    [ "modulationWave", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1___delay_stage_parameter_data.html#a8a44b1e7c1ec712f3a2650c760fc375b", null ]
];