var struct_so_x_plugins_1_1_helpers_1_1_so_x_value_change_observer =
[
    [ "SoXValueChangeObserver", "struct_so_x_plugins_1_1_helpers_1_1_so_x_value_change_observer.html#a1ddb442d94be6c6dbb0435cfbfa17062", null ],
    [ "notifyAboutValueChange", "struct_so_x_plugins_1_1_helpers_1_1_so_x_value_change_observer.html#a3f7304dfaf436e36f1bf502228a5174a", null ],
    [ "set", "struct_so_x_plugins_1_1_helpers_1_1_so_x_value_change_observer.html#a88581b8d8200503ea3a112fe384fc9bd", null ],
    [ "_notificationProc", "struct_so_x_plugins_1_1_helpers_1_1_so_x_value_change_observer.html#ac9cc11ce53a1c614297a0d92e11f15af", null ],
    [ "_valueChangeHandler", "struct_so_x_plugins_1_1_helpers_1_1_so_x_value_change_observer.html#a192b594802b696076f873abbae30a995", null ]
];