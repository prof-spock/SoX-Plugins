var struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1_so_x_flanger_phaser_and_tremolo___audio_effect =
[
    [ "_applyForFrame", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1_so_x_flanger_phaser_and_tremolo___audio_effect.html#a7e4fddfd2eda5e8b4234941a0607af36", null ],
    [ "_effectDescriptorToString", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1_so_x_flanger_phaser_and_tremolo___audio_effect.html#a9469712f3b7eac5401d4d7ca5fa7f1f5", null ],
    [ "_handleDataPointRateChange", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1_so_x_flanger_phaser_and_tremolo___audio_effect.html#ac9555c5be898b781d5d684ccd60bb475", null ],
    [ "_internalState", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1_so_x_flanger_phaser_and_tremolo___audio_effect.html#aa6e4897d196ae3ed40e17bbe12a6a746", null ],
    [ "_setValueInternal", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1_so_x_flanger_phaser_and_tremolo___audio_effect.html#adfbfe9e11179867f140ec67486a02ebc", null ],
    [ "isTimeVariant", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1_so_x_flanger_phaser_and_tremolo___audio_effect.html#a163bb10a0e4de4ec7940183c1b4c50c1", null ],
    [ "name", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1_so_x_flanger_phaser_and_tremolo___audio_effect.html#ac88c71d9cec09d216d87fdc78777c2e2", null ],
    [ "recalculate", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1_so_x_flanger_phaser_and_tremolo___audio_effect.html#a7f2fe6bafb2b125f1d1666a41d113806", null ],
    [ "setDefaultValues", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1_so_x_flanger_phaser_and_tremolo___audio_effect.html#a21e53d1553ac9b2b41876dab6cef5e79", null ],
    [ "tailLength", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1_so_x_flanger_phaser_and_tremolo___audio_effect.html#a6ec386a8d3a62f29df343c9ed734206b", null ]
];