var namespace_so_x_plugins_1_1_helpers =
[
    [ "SoXAudioHelper", "struct_so_x_plugins_1_1_helpers_1_1_so_x_audio_helper.html", "struct_so_x_plugins_1_1_helpers_1_1_so_x_audio_helper" ],
    [ "SoXEffectParameterMap", "struct_so_x_plugins_1_1_helpers_1_1_so_x_effect_parameter_map.html", "struct_so_x_plugins_1_1_helpers_1_1_so_x_effect_parameter_map" ],
    [ "SoXEmulationHelper", "struct_so_x_plugins_1_1_helpers_1_1_so_x_emulation_helper.html", "struct_so_x_plugins_1_1_helpers_1_1_so_x_emulation_helper" ],
    [ "SoXValueChangeObserver", "struct_so_x_plugins_1_1_helpers_1_1_so_x_value_change_observer.html", "struct_so_x_plugins_1_1_helpers_1_1_so_x_value_change_observer" ],
    [ "SoXValueChangeNotification", "namespace_so_x_plugins_1_1_helpers.html#a445ec43c8d0d8a5489ebb50a05415df7", null ],
    [ "SoXEffectParameterKind", "namespace_so_x_plugins_1_1_helpers.html#a782a7054af4fe4d3821edfd71bb275d3", [
      [ "realKind", "namespace_so_x_plugins_1_1_helpers.html#a782a7054af4fe4d3821edfd71bb275d3a22c6e82b48bf8d55cb19b0b26bd1d304", null ],
      [ "intKind", "namespace_so_x_plugins_1_1_helpers.html#a782a7054af4fe4d3821edfd71bb275d3a5e5e1c01600128b2d03b17fce13ef730", null ],
      [ "enumKind", "namespace_so_x_plugins_1_1_helpers.html#a782a7054af4fe4d3821edfd71bb275d3ac5d7c625096e2f08cc986dc414835eaf", null ],
      [ "unknownKind", "namespace_so_x_plugins_1_1_helpers.html#a782a7054af4fe4d3821edfd71bb275d3af871b51599f44c270ee400d5a1012a2e", null ]
    ] ],
    [ "SoXValueChangeKind", "namespace_so_x_plugins_1_1_helpers.html#a375d28eeb638976b8eba48c078910178", [
      [ "noChange", "namespace_so_x_plugins_1_1_helpers.html#a375d28eeb638976b8eba48c078910178ad37ddf64a872257d1805878d69aa9e6d", null ],
      [ "parameterChange", "namespace_so_x_plugins_1_1_helpers.html#a375d28eeb638976b8eba48c078910178ad099a3a097d6349d897c64f783e1239d", null ],
      [ "globalChange", "namespace_so_x_plugins_1_1_helpers.html#a375d28eeb638976b8eba48c078910178ab6c1503bf3ca26a7932d2f6227ec2ba3", null ]
    ] ],
    [ "effectParameterKindToString", "namespace_so_x_plugins_1_1_helpers.html#ae93620731c315c64e04114c04b0598e6", null ],
    [ "SoXValueChangeKind_toString", "namespace_so_x_plugins_1_1_helpers.html#af7beeb73037cd9a9497e283c61888073", null ]
];