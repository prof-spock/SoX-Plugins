var struct_so_x_plugins_1_1_effects_1_1_so_x_overdrive_1_1_so_x_overdrive___audio_effect =
[
    [ "_applyForFrame", "struct_so_x_plugins_1_1_effects_1_1_so_x_overdrive_1_1_so_x_overdrive___audio_effect.html#ace335717fa8b46e6829ff8f34d3e9f55", null ],
    [ "_effectDescriptorToString", "struct_so_x_plugins_1_1_effects_1_1_so_x_overdrive_1_1_so_x_overdrive___audio_effect.html#a8cb97a9f31655fc9e214fbd1891c48de", null ],
    [ "_setValueInternal", "struct_so_x_plugins_1_1_effects_1_1_so_x_overdrive_1_1_so_x_overdrive___audio_effect.html#aa678cfffb8a819f358360f28e8e39985", null ],
    [ "name", "struct_so_x_plugins_1_1_effects_1_1_so_x_overdrive_1_1_so_x_overdrive___audio_effect.html#a935d301106298215ee2f9d0876517d99", null ],
    [ "recalculate", "struct_so_x_plugins_1_1_effects_1_1_so_x_overdrive_1_1_so_x_overdrive___audio_effect.html#a272f3d2f5395d489a243291ccf8e4e33", null ],
    [ "setDefaultValues", "struct_so_x_plugins_1_1_effects_1_1_so_x_overdrive_1_1_so_x_overdrive___audio_effect.html#aa0d8e076c4b664d6eaf31834c2ad6beb", null ],
    [ "tailLength", "struct_so_x_plugins_1_1_effects_1_1_so_x_overdrive_1_1_so_x_overdrive___audio_effect.html#af79c7e423818248a424e539a0f44925f", null ]
];