var dir_1d8ad4e22bddba08da5448ad89771a30 =
[
    [ "JucePluginDefines.h", "_so_x_overdrive_2_juce_plugin_defines_8h.html", "_so_x_overdrive_2_juce_plugin_defines_8h" ],
    [ "SoXOverdrive_AudioEffect.cpp", "_so_x_overdrive___audio_effect_8cpp.html", "_so_x_overdrive___audio_effect_8cpp" ],
    [ "SoXOverdrive_AudioEffect.h", "_so_x_overdrive___audio_effect_8h.html", "_so_x_overdrive___audio_effect_8h" ],
    [ "SoXOverdrive_AudioProcessor.cpp", "_so_x_overdrive___audio_processor_8cpp.html", "_so_x_overdrive___audio_processor_8cpp" ]
];