var struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1_so_x_chorus_and_echo___audio_effect =
[
    [ "_applyForFrame", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1_so_x_chorus_and_echo___audio_effect.html#a768745164fc713fbbba796bf2950a573", null ],
    [ "_effectDescriptorToString", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1_so_x_chorus_and_echo___audio_effect.html#a8dc3fec6913fb5cff6f9c31bba5d47c4", null ],
    [ "_handleDataPointRateChange", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1_so_x_chorus_and_echo___audio_effect.html#a2701da41df8a4ca08a82bad57584a604", null ],
    [ "_internalState", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1_so_x_chorus_and_echo___audio_effect.html#a87963d154899ee9db1692f9e86cb22e2", null ],
    [ "_setValueInternal", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1_so_x_chorus_and_echo___audio_effect.html#a7a8fac5a3807f779488e383dc9c88d46", null ],
    [ "isTimeVariant", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1_so_x_chorus_and_echo___audio_effect.html#a64ed9ec57c837d69b045fe5b10aff395", null ],
    [ "name", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1_so_x_chorus_and_echo___audio_effect.html#a3cb6c4c31858478d06c2c67866e5d2be", null ],
    [ "recalculate", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1_so_x_chorus_and_echo___audio_effect.html#a24d0dccca7a03a1bdd15bcde5723032a", null ],
    [ "setDefaultValues", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1_so_x_chorus_and_echo___audio_effect.html#aefe16f7d3f98450bf0e851bf3630c0aa", null ],
    [ "tailLength", "struct_so_x_plugins_1_1_effects_1_1_so_x_chorus_and_echo_1_1_so_x_chorus_and_echo___audio_effect.html#a2389fcd4f53ebbec5d63f4e898dfb076", null ]
];