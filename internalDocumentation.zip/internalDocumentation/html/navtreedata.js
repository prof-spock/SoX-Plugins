/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "SoXPlugins", "index.html", [
    [ "SoXPlugins - SoX Effects for DAWs", "index.html", null ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Variables", "namespacemembers_vars.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ],
        [ "Enumerations", "namespacemembers_enum.html", null ],
        [ "Enumerator", "namespacemembers_eval.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", null ],
        [ "Variables", "globals_vars.html", "globals_vars" ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_assertion_8h.html",
"_so_x_audio_editor_8cpp.html#aa7799229fb7458f65ec7d035e0f4b573",
"_so_x_flanger_phaser_and_tremolo_2_juce_plugin_defines_8h.html#a7ea0aae73bd9068752aab30c6883d965",
"class_base_modules_1_1___logging_time.html#ab820a750e5b908dac86ddbc07acf024a",
"namespace_so_x_plugins_1_1_helpers.html#a782a7054af4fe4d3821edfd71bb275d3a22c6e82b48bf8d55cb19b0b26bd1d304",
"struct_audio_1_1_audio_data_point_list.html#abaf62fa1de2bd04007d5103182173490",
"struct_audio_data_point_ring_buffer_vector.html#a5b0f89b48294621c8993ae95f95c5324",
"struct_base_types_1_1_containers_1_1_dictionary.html#aa373f05cc631a03e49a100fd8c340fca",
"struct_base_types_1_1_primitives_1_1_real.html",
"struct_logging.html#ab4d7a5c504f4e9c7edb3bdda8276e02c",
"struct_so_x_effect_parameter_map.html#a22e31746f12c941c691dac82eb804d9f",
"struct_so_x_plugins_1_1_effects_1_1_so_x_compander_1_1___compander.html#a75480b093f0698763337a37d6ee84020",
"struct_so_x_plugins_1_1_effects_1_1_so_x_filter_1_1___effect_descriptor___f_l_t_r.html#a78f77d8046638576fb68cc261e6517d2",
"struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1___reverb_channel.html#ab7bf81e71160577789bf83813043928a",
"struct_so_x_plugins_1_1_view_and_controller_1_1_so_x_audio_editor.html#a3aa244ad6e8c374cc12e6bf578718a40"
];

var SYNCONMSG = 'click to disable panel synchronization';
var SYNCOFFMSG = 'click to enable panel synchronization';
var LISTOFALLMEMBERS = 'List of all members';