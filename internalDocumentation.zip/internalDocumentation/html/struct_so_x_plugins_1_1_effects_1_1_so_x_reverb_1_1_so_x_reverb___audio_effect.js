var struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1_so_x_reverb___audio_effect =
[
    [ "_applyForFrame", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1_so_x_reverb___audio_effect.html#a91acd4a62f31c31bca55383be01b1a36", null ],
    [ "_effectDescriptorToString", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1_so_x_reverb___audio_effect.html#ab1857ea621be27a96487311e90d4861c", null ],
    [ "_handleDataPointRateChange", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1_so_x_reverb___audio_effect.html#ad01ef5d8a8e41b8cedb241302449679a", null ],
    [ "_setValueInternal", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1_so_x_reverb___audio_effect.html#a8b465c987c93cdf7afa8d974bfb20266", null ],
    [ "name", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1_so_x_reverb___audio_effect.html#ac75d76009a42c82b5fcf3be39079046e", null ],
    [ "recalculate", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1_so_x_reverb___audio_effect.html#acf2ee5f75c39e5baec58fbfeeb969b22", null ],
    [ "setDefaultValues", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1_so_x_reverb___audio_effect.html#aaaf7de83bf2d2fb2cecda81b9b25e22a", null ],
    [ "tailLength", "struct_so_x_plugins_1_1_effects_1_1_so_x_reverb_1_1_so_x_reverb___audio_effect.html#a39d81446d23dc3d4e4e9eabc740f8372", null ]
];