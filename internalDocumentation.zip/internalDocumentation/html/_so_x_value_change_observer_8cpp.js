var _so_x_value_change_observer_8cpp =
[
    [ "SoXValueChangeNotification", "_so_x_value_change_observer_8cpp.html#a445ec43c8d0d8a5489ebb50a05415df7", null ],
    [ "SoXPlugins::Helpers::SoXValueChangeKind_toString", "namespace_so_x_plugins_1_1_helpers.html#af7beeb73037cd9a9497e283c61888073", null ]
];