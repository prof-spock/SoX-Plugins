var struct_so_x_audio_editor =
[
    [ "SoXAudioEditor", "struct_so_x_audio_editor.html#ae5fb12ab174bec80155f637283bc2ee2", null ],
    [ "_resetAppearance", "struct_so_x_audio_editor.html#a7653fa859b60da5599f0ec6f5e33d3ec", null ],
    [ "effectParameterMap", "struct_so_x_audio_editor.html#a3aa244ad6e8c374cc12e6bf578718a40", null ],
    [ "notifyAboutChange", "struct_so_x_audio_editor.html#af41857366991f777166e1e99a6271e26", null ],
    [ "paint", "struct_so_x_audio_editor.html#ab808cca23fb0396e2fee0735363129aa", null ],
    [ "resized", "struct_so_x_audio_editor.html#a3431283de8306558657789c6b777e210", null ],
    [ "setValue", "struct_so_x_audio_editor.html#a7cce766106bb4a4c5e4f4c446334da6f", null ],
    [ "_commonWidgetCount", "struct_so_x_audio_editor.html#a35a1575b4b7fbc4c3d8af52d66ffd0f7", null ],
    [ "_currentEditorPageIndex", "struct_so_x_audio_editor.html#a1a8b7195cc304b397505b8d3544f39c2", null ],
    [ "_lastEditorPageIndex", "struct_so_x_audio_editor.html#a42ebb1fb23bdad67b235080e7cc50f0c", null ],
    [ "_maximumWidgetCount", "struct_so_x_audio_editor.html#a5905fb31fdf166b11e2b1748f1063a12", null ],
    [ "_processor", "struct_so_x_audio_editor.html#afe49fc1a792cc7495a92f175fc836838", null ],
    [ "_widgetList", "struct_so_x_audio_editor.html#a35604af565699f8336bbeba14257c53b", null ]
];