var struct_audio_1_1_delay_line_list =
[
    [ "DelayLineList", "struct_audio_1_1_delay_line_list.html#a4366cb4c5071498610047bef53a27552", null ],
    [ "setElementInterpolation", "struct_audio_1_1_delay_line_list.html#a97add5a75a7ec9c94e850c7689b635d0", null ],
    [ "setElementLength", "struct_audio_1_1_delay_line_list.html#acf3f3c833a24f7fd13c549fd7ddb3be3", null ],
    [ "setToZero", "struct_audio_1_1_delay_line_list.html#a7bcc7412f14643e67f3e1c653656a3f1", null ]
];