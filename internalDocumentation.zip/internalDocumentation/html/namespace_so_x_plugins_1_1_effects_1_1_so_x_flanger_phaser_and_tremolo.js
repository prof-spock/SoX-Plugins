var namespace_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo =
[
    [ "_EffectDescriptor_FPHT", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t.html", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1___effect_descriptor___f_p_h_t" ],
    [ "SoXFlangerPhaserAndTremolo_AudioEffect", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1_so_x_flanger_phaser_and_tremolo___audio_effect.html", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1_so_x_flanger_phaser_and_tremolo___audio_effect" ],
    [ "SoXFlangerPhaserAndTremolo_AudioProcessor", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1_so_x_flanger_phaser_and_tremolo___audio_processor.html", "struct_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo_1_1_so_x_flanger_phaser_and_tremolo___audio_processor" ],
    [ "_EffectKind", "namespace_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo.html#ac3c13c66b983842b1ec8a6fb5072ff4f", [
      [ "unknown", "namespace_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo.html#ac3c13c66b983842b1ec8a6fb5072ff4faad921d60486366258809553a3db49a4a", null ],
      [ "flanger", "namespace_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo.html#ac3c13c66b983842b1ec8a6fb5072ff4faed84fe5069df2ffe054d771db83de633", null ],
      [ "phaser", "namespace_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo.html#ac3c13c66b983842b1ec8a6fb5072ff4fa83bdc3f445d043064dc14a3e6f1c4026", null ],
      [ "tremolo", "namespace_so_x_plugins_1_1_effects_1_1_so_x_flanger_phaser_and_tremolo.html#ac3c13c66b983842b1ec8a6fb5072ff4faa8fa0aaf5f88e6a54f3fdab523ae7979", null ]
    ] ]
];