var _so_x_value_change_observer_8h =
[
    [ "SoXPlugins::Helpers::SoXValueChangeObserver", "struct_so_x_plugins_1_1_helpers_1_1_so_x_value_change_observer.html", "struct_so_x_plugins_1_1_helpers_1_1_so_x_value_change_observer" ],
    [ "Object", "_so_x_value_change_observer_8h.html#a46e9a7b488f5aadebd3b8413adf482f6", null ],
    [ "SoXPlugins::Helpers::SoXValueChangeNotification", "namespace_so_x_plugins_1_1_helpers.html#a445ec43c8d0d8a5489ebb50a05415df7", null ],
    [ "String", "_so_x_value_change_observer_8h.html#aa37c6ea28e4f3e4a9ceab460d9bc88fc", null ],
    [ "SoXPlugins::Helpers::SoXValueChangeKind", "namespace_so_x_plugins_1_1_helpers.html#a375d28eeb638976b8eba48c078910178", [
      [ "SoXPlugins::Helpers::SoXValueChangeKind::noChange", "namespace_so_x_plugins_1_1_helpers.html#a375d28eeb638976b8eba48c078910178ad37ddf64a872257d1805878d69aa9e6d", null ],
      [ "SoXPlugins::Helpers::SoXValueChangeKind::parameterChange", "namespace_so_x_plugins_1_1_helpers.html#a375d28eeb638976b8eba48c078910178ad099a3a097d6349d897c64f783e1239d", null ],
      [ "SoXPlugins::Helpers::SoXValueChangeKind::globalChange", "namespace_so_x_plugins_1_1_helpers.html#a375d28eeb638976b8eba48c078910178ab6c1503bf3ca26a7932d2f6227ec2ba3", null ]
    ] ],
    [ "SoXPlugins::Helpers::SoXValueChangeKind_toString", "namespace_so_x_plugins_1_1_helpers.html#af7beeb73037cd9a9497e283c61888073", null ]
];