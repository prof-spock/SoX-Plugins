var struct___reverb_effect_parameter_data =
[
    [ "toString", "struct___reverb_effect_parameter_data.html#a16e77d48379eb8fb8e4999ecfbe1a112", null ],
    [ "channelCount", "struct___reverb_effect_parameter_data.html#a4c9ee4c396a800d35041eba11f4f1ec7", null ],
    [ "dataPointRate", "struct___reverb_effect_parameter_data.html#adf8c8b40ae340fb95a4f4552057e839d", null ],
    [ "feedback", "struct___reverb_effect_parameter_data.html#a9ac458b45cd764d0b6630ba594b96128", null ],
    [ "hfDamping", "struct___reverb_effect_parameter_data.html#a921b82dd6d9604786a4472ec496c4891", null ],
    [ "isWetOnly", "struct___reverb_effect_parameter_data.html#af3c59b354f12df6c5f2f355b722cd275", null ],
    [ "predelay", "struct___reverb_effect_parameter_data.html#aaf4a513580431117c703ae74fd293a8b", null ],
    [ "reverbChannelList", "struct___reverb_effect_parameter_data.html#a7e5c79e8830e18f6466a0c5a3c03b6ec", null ],
    [ "roomScale", "struct___reverb_effect_parameter_data.html#afdb8c38968e7ec6b8989cecfd46d6cbe", null ],
    [ "stereoDepth", "struct___reverb_effect_parameter_data.html#a31a970af5cf25ed14248a0df63afb045", null ],
    [ "wetGain", "struct___reverb_effect_parameter_data.html#ae2e81a18c1e9266e0b54c7a3eec28258", null ]
];