var struct_so_x_plugins_1_1_effects_1_1_so_x_gain_1_1_so_x_gain___audio_effect =
[
    [ "_applyForFrame", "struct_so_x_plugins_1_1_effects_1_1_so_x_gain_1_1_so_x_gain___audio_effect.html#ab14facb924bd58f28dc2b5a61352a281", null ],
    [ "_effectDescriptorToString", "struct_so_x_plugins_1_1_effects_1_1_so_x_gain_1_1_so_x_gain___audio_effect.html#ac693df8a8257e645ee22e4790146b3b6", null ],
    [ "_setValueInternal", "struct_so_x_plugins_1_1_effects_1_1_so_x_gain_1_1_so_x_gain___audio_effect.html#ae0e54a459c93b068f12b8f0ee711e4ad", null ],
    [ "name", "struct_so_x_plugins_1_1_effects_1_1_so_x_gain_1_1_so_x_gain___audio_effect.html#a64403409949ef9090f5f99cd537cb41e", null ],
    [ "setDefaultValues", "struct_so_x_plugins_1_1_effects_1_1_so_x_gain_1_1_so_x_gain___audio_effect.html#a0fd7bccea58fa28676f2d47d3ba8bd37", null ]
];