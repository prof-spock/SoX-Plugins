var struct___effect_parameter_listener =
[
    [ "audioProcessor", "struct___effect_parameter_listener.html#a0b7b4c21dc14b8b9687b4463f12b1a11", null ]
];