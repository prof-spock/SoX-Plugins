var dir_bba0a06b7c5bf1521d83c5188eb207fb =
[
    [ "SoXAudioHelper.h", "_so_x_audio_helper_8h.html", "_so_x_audio_helper_8h" ],
    [ "SoXEffectParameterMap.cpp", "_so_x_effect_parameter_map_8cpp.html", "_so_x_effect_parameter_map_8cpp" ],
    [ "SoXEffectParameterMap.h", "_so_x_effect_parameter_map_8h.html", "_so_x_effect_parameter_map_8h" ],
    [ "SoXEmulationHelper.h", "_so_x_emulation_helper_8h.html", "_so_x_emulation_helper_8h" ],
    [ "SoXValueChangeObserver.cpp", "_so_x_value_change_observer_8cpp.html", "_so_x_value_change_observer_8cpp" ],
    [ "SoXValueChangeObserver.h", "_so_x_value_change_observer_8h.html", "_so_x_value_change_observer_8h" ]
];