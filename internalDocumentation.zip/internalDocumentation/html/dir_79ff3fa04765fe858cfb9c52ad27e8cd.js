var dir_79ff3fa04765fe858cfb9c52ad27e8cd =
[
    [ "JucePluginDefines.h", "_so_x_filter_2_juce_plugin_defines_8h.html", "_so_x_filter_2_juce_plugin_defines_8h" ],
    [ "SoXFilter_AudioEffect.cpp", "_so_x_filter___audio_effect_8cpp.html", "_so_x_filter___audio_effect_8cpp" ],
    [ "SoXFilter_AudioEffect.h", "_so_x_filter___audio_effect_8h.html", "_so_x_filter___audio_effect_8h" ],
    [ "SoXFilter_AudioProcessor.cpp", "_so_x_filter___audio_processor_8cpp.html", "_so_x_filter___audio_processor_8cpp" ]
];