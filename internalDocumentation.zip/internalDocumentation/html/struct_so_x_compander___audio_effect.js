var struct_so_x_compander___audio_effect =
[
    [ "_applyForFrame", "struct_so_x_compander___audio_effect.html#afbc2599e40bf36c2e5151fbfae6db96f", null ],
    [ "_effectDescriptorToString", "struct_so_x_compander___audio_effect.html#ad62653eb5b6f044fe12974533b9f96d1", null ],
    [ "_handleDataPointRateChange", "struct_so_x_compander___audio_effect.html#a7fd0d119458cc42a3a0d017996d580d9", null ],
    [ "_setValueInternal", "struct_so_x_compander___audio_effect.html#abd0cfcc5ef9242d10aaee0e3f4127cab", null ],
    [ "name", "struct_so_x_compander___audio_effect.html#a753f566112fed8c2eed9cf6b802f25f9", null ],
    [ "recalculate", "struct_so_x_compander___audio_effect.html#a6c1d948a75f80d8514e17c37da61c075", null ],
    [ "setDefaultValues", "struct_so_x_compander___audio_effect.html#a63944d4f84f7c24989ea91f09a8e22ea", null ]
];