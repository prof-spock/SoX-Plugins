var struct_so_x_emulation_helper =
[
    [ "adaptValueForSoXEmulation", "struct_so_x_emulation_helper.html#a3533860ca75546741fcdb5cd8f799d29", null ],
    [ "soxIsStrictlyEmulated", "struct_so_x_emulation_helper.html#aa37fb9a318eff936c02f02c617c1b353", null ]
];